//var siteUrl = "http://"+window.location.host ;
//if(siteUrl.indexOf("map") == -1){
//  siteUrl = siteUrl+"/dianziditu/" ;
//}
siteUrl =  "http://jushi-yanshi.tidemedia.com" ;
var allnav  = siteUrl + "/map/d/allnav.json";
var listUrl = "" ;
console.log(siteUrl) ;
var ztlist = "/map/c/ztlist.shtml" ;
var allviews = "/map/d/allviews.json"
//var siteUrl = "http://"+window.location.host ;

//公共弹窗函数
function commonPop(tips){
    $("#commonpop").stop().hide();
    $("#commonpop span").html(tips);		 
    $("#commonpop").fadeIn(1);
    var popInterval = setTimeout(function() {		    	
        $("#commonpop").fadeOut(300);
        clearTimeout(popInterval);
    }, 3000);  
}

//获取地址栏参数
function getUrl(name) {
    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
    var r = window.location.search.substr(1).match(reg);
     if(r!=null)return  unescape(r[2]); return null;
};

//sessionStorage
function sSs(key,value){
    if(value==undefined || value===undefined ){
        return sessionStorage.getItem(key);//获取指定key本地存储的值
    }
    if(value==null){
        sessionStorage.removeItem(key);//删除指定key本地存储的值
        return true;
    }
    sessionStorage.setItem(key,value);//将value存储到key字段
    return true;
};	

//返回完整链接
function returnWhole(_url){
	if(_url.substr(0,4)!="http"){
       _url  = ""+siteUrl + _url  ;
    } 
    return _url ;
}

//星级显示   
function dispalyStars(s){
	var startsHtml = " " ;
	if(s<2){
		startsHtml +='<li class="star half"></li>' ;
	}else{
		startsHtml +='<li class="star red"></li>' ;
	}
	
	if(s<3){
		startsHtml +='<li class="star"></li>' ;
	}else if(s==3){
		startsHtml +='<li class="star half"></li>' ;
	}else if(s>=4){
		startsHtml +='<li class="star red"></li>' ;
	}
	
	if(s<5){
		startsHtml +='<li class="star"></li>' ;
	}else if(s==5){
		startsHtml +='<li class="star half"></li>' ;
	}else if(s>=6){
		startsHtml +='<li class="star red"></li>' ;
	}
	
	if(s<7){
		startsHtml +='<li class="star"></li>' ;
	}else if(s==7){
		startsHtml +='<li class="star half"></li>' ;
	}else if(s>=8){
		startsHtml +='<li class="star red"></li>' ;
	}
	
	if(s<9){
		startsHtml +='<li class="star"></li>' ;
	}else if(s==9){
		startsHtml +='<li class="star half"></li>' ;
	}else if(s>=10){
		startsHtml +='<li class="star red"></li>' ;
	}
	return startsHtml ;
}

;$(function(){
    var u = navigator.userAgent;
    var isiOS = !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/); //ios终端
    if(isiOS){
       // $('.backpage').show();
    }
    
    $('.backpage').click(function(){
       history.back(-1)
    });
   
        // 返回顶部
    $(window).scroll(function(){
    	$('.top').show();
    	if($(window).scrollTop() <= 200){
    		$('.top').hide();
    	}
    });
    $('.top').click(function(){
    	$(window).scrollTop(0);
    });
})
 
