var positionArr = null ;
var jwdArr= null ;
var map ;
//实例
var channelid=getUrl("id") ? getUrl("id") : 0;
var keywords = getUrl("keywords") ? decodeURI(escape(getUrl("keywords"))) : ""; 
  
;$(function(){
	//请求导航
	getNav();
	function getNav(){
	    $.ajax({
			type:"get",
			url: allnav,				  		
			dataType:"json",
			success:function(data){
				console.log(data)
				var liHtml = "" ;
        		for(var i=0;i<data.length;i++){
        			if(data[i].channelID==channelid && channelid != 0){
        				liHtml +='<li class="active" data-id="'+data[i].channelID+'" data-jwd="'+data[i].jwd+'" data-list="'+data[i].listUrl+'"><a class="" href="javascript:;">'+data[i].channelName+'</a></li>'  ;
        				$(".area-name span").html(data[i].channelName);
        				listUrl = siteUrl+data[i].listUrl;  
        			}else if(channelid == 0 && i==0){
        			    liHtml +='<li class="active" data-id="'+data[i].channelID+'"  data-jwd="'+data[i].jwd+'" data-list="'+data[i].listUrl+'"><a class="" href="javascript:;">'+data[i].channelName+'</a></li>' ;
        			    //$(".area-name span").html(data[i].channelName);
        			    $(".area-name span").html("全部地区");
        				listUrl = siteUrl+data[i].listUrl;  //默认请求全部数据
        			}else{
        				liHtml +='<li data-id="'+data[i].channelID+'" data-jwd="'+data[i].jwd+'" data-list="'+data[i].listUrl+'"><a class="" href="javascript:;">'+data[i].channelName+'</a></li>'
        			}				
        		}
        		
        		$(".nav-list").html(liHtml);
        		if(keywords){
        		    showSearch(keywords);
        		}else{
        		    getData();  
        		}
        		changeNav();
			}
		});
	}
});


 //搜索
$(".search-box input").on('keypress',function(e) {
    var text=$(this).val();
    if(text==""){
        alert("请输入景区关键词！");
        return ;
    }
    if($(".switch").hasClass("list")){
        $(".area-box").show();
        $("#BDMap").hide();
        $(".switch").removeClass('list');
    }
    showSearch(text);
    e.preventDefault();
});

function showSearch(words){
    console.log(1111,words)
    $(".switch").hide();
    $(".search-box input").val(words)
    $.ajax({
        url:allviews,
        dataType:"json",
        success:function(data){
        
        	var listHtml = "" ;
        	for(var i=0;i<data.length;i++){
        	    if(data[i].title.indexOf(words) != -1 ){
        	        listHtml += '<div class="list-item" data-url="'+data[i].contenturl+'">'+
        		        '<div class="img-box">'+
        		            '<img src="'+data[i].photo+'" />'+
        		        '</div>'+
        		        '<div class="text-box">'+
        		        	'<div class="title">'+
        		        		'<h5>'+data[i].title+'</h5>'+
        		        		'<div class="stars">'+
        		        			'<ul>'+dispalyStars(data[i].score)+'</ul>'+
        		        		'</div>'+
        	        		'</div>'+
        	        		'<p class="area-detail">'+data[i].summary+'</p>'+
        		        '</div>'+
        		    '</div>'
        	    }
        	}
        	if(listHtml!=""){
        	    $(".area-list").html(listHtml);	
        	}else{
        	    $(".area-list").html('<div class="no-more-info">暂无结果</div>');
        	}
        	
        },
        error:function(e){
        	
        	$(".container .newsPage").append('<div class="no-more-info">没有更多内容了</div>');
        }
	})
}

//切换景区
$(".header-nav .area-name").click(function(){
	$(this).toggleClass("ac") ;
	if($(this).hasClass("ac")){
		$(".nav-box").slideDown(200) ;
		$("body").css("overflow","hidden");
		$(this).find("i").removeClass("fa-caret-down").addClass("fa-caret-up")
	}else{
		$(".nav-box").slideUp(200) ;
		$("body").css("overflow","visible");
		$(this).find("i").addClass("fa-caret-down").removeClass("fa-caret-up")
	}
	return false;
});

function changeNav(){
	$("ul.nav-list li").click(function(e){
	    
        pagenum  = 1 ;
        havaNextPage = true ; 
        _switch  = true ;   
	    
    	$(this).addClass("active").siblings().removeClass("active") ;
    	var _area = $(this).find("a").text() ;
    	listUrl = siteUrl+$(this).attr("data-list");
  	    getData()
    
    	$(".header-nav .area-name span").text(_area);
    	$(".nav-box").slideUp(200) ;
    	$("body").css("overflow","visible");
    	$(".header-nav .area-name").removeClass("ac").find("i").addClass("fa-caret-down").removeClass("fa-caret-up") ;           	
    	$(".switch").show();
    	$(".search-box input").val("")
    	return false;
    });
}

$(".nav-box .nav-cancle").click(function(){
	$(".nav-box").slideUp(200) ;	
	$(".header-nav .area-name").removeClass("ac") ;
	$("body").css("overflow","visible");
	$(".header-nav .area-name").find("i").addClass("fa-caret-down").removeClass("fa-caret-up")
	return false;
});

var pagenum  = 1 ;
var havaNextPage = true ;  //是否有下一页
//var _url = 'list_more_'+pagenum+'.shtml' ;
var _switch  = true ;   //开关，防止一次下拉触发多次接口请求
    
function getData(){
	if(!havaNextPage){
		return false;
	}	
	console.log(listUrl);
	$.ajax({
        url:listUrl,
        dataType:"json",
        beforeSend:function(XMLHttpRequest){ 
        	if(pagenum>1){
        		$(".loading").show();
        	}
        	_switch = false ;
		}, 
        success:function(data){
        	pagenum ++ ;
        	
        	listUrl = listUrl.replace(/.shtml/g, '_'+pagenum+'.shtml') ;
        	_switch = true ;
        	$(".loading").fadeOut("slow");
        	var listHtml = "" ;
        	for(var i=0;i<data.list.length;i++){
        		listHtml += '<div class="list-item" data-url="'+data.list[i].contenturl+'">'+
        		        '<div class="img-box">'+
        		            '<img src="'+data.list[i].photo+'" />'+
        		        '</div>'+
        		        '<div class="text-box">'+
        		        	'<div class="title">'+
        		        		'<h5>'+data.list[i].title+'</h5>'+
        		        		'<div class="stars">'+
        		        			'<ul>'+dispalyStars(data.list[i].score)+'</ul>'+
        		        		'</div>'+
        	        		'</div>'+
        	        		'<p class="area-detail">'+data.list[i].summary+'</p>'+
        		        '</div>'+
        		    '</div>'
        	}
        	positionArr = data.list;
        	jwdArr = [] ;
        	jwdArr = data.jwd ;
            if(pagenum<=2){
                $(".area-list").html(listHtml);	
            }else{
                $(".area-list").append(listHtml);	
            }
        	
            console.log(positionArr)
        	addMarker(positionArr) ;
        },
        error:function(e){
        	havaNextPage = false ;
        	$(".loading").fadeOut("slow");
        	_switch = false ;
        	//$(".container .newsPage").find(".no-more-info").remove();
        	$(".container .newsPage").append('<div class="no-more-info">没有更多内容了</div>');
        }
	})
}

//滚动的上拉刷新
$(".content-box").scroll(function(){  	
	//console.log(123)
	$('.top').show();
    	if($(".content-box").scrollTop() <= 200){
    		$('.top').hide();
    }
    if($(".content-box").scrollTop() >= $(".area-box").height()-$(".content-box").height()) {	
    	if(_switch){
		    getData();	        	
        	return false;
		}
       
	}
});
$('.top').click(function(){
    $(".content-box").animate({scrollTop:0},300)
});
//   切换列表/地图模式
$(".switch").click(function(){
    if($(this).hasClass("list")){
        $(".area-box").show();
        $("#BDMap").hide();
        $(this).removeClass('list');
        return ;
    }else{
        $(".area-box").hide();
        console.log(positionArr)
        $("#BDMap").show();
        addMarker(positionArr) ;
        
        $(this).addClass('list');
        return ;
    }
})


function setCenterAndZoom(pos){
   	if(!pos[0]){
   	    console.log(0)
   	    map.centerAndZoom(new BMap.Point(118.339112,29.721638), 10);
   	}else{
   	    map.centerAndZoom(new BMap.Point(pos[0].lng, pos[0].lat), 10);
   	}
}

function jumpToContent(_this){
    event.stopPropagation();
    var _href = $(_this.content).attr("href") ;
    window.open(_href,"_blank");
    return false ;
} 

//列表页跳转
$(".area-list").delegate(".list-item","click",function(){
    
	var _url =  siteUrl+ $(this).attr("data-url") ;
	console.log(_url)
	window.open(_url,"_blank");
})



//地图上天剑标注
function addMarker(points) {
    //循环建立标注点
    console.log(points)

     map = new BMap.Map("BDMap");    
    //map.centerAndZoom(new BMap.Point(116.403849, 39.915446), 15);  // 设置中心点
    // map.centerAndZoom("黄山");
    // map.setCurrentCity("黄山");          
    map.addControl(new BMap.MapTypeControl({mapTypes: [BMAP_NORMAL_MAP,BMAP_HYBRID_MAP]}));   
    map.enableScrollWheelZoom(true);
    // var opts = {type: BMAP_NAVIGATION_CONTROL_ZOOM};
    // map.addControl(new BMap.NavigationControl(opts));



    // 添加带有定位的导航控件
  var navigationControl = new BMap.NavigationControl({
    // 靠左上角位置
    anchor: BMAP_ANCHOR_TOP_LEFT,
    // LARGE类型
    type: BMAP_NAVIGATION_CONTROL_LARGE,
    // 启用显示定位
    enableGeolocation: true
  });
  map.addControl(navigationControl);
  // 添加定位控件
  var geolocationControl = new BMap.GeolocationControl();
  geolocationControl.addEventListener("locationSuccess", function(e){
    // 定位成功事件
    var address = '';
    address += e.addressComponent.province;
    address += e.addressComponent.city;
    address += e.addressComponent.district;
    address += e.addressComponent.street;
    address += e.addressComponent.streetNumber;
    //alert("当前定位地址为：" + address);
  });
  geolocationControl.addEventListener("locationError",function(e){
    // 定位失败事件
    alert(e.message);
  });
  map.addControl(geolocationControl);
    for(var i=0, pointsLen = points.length; i<pointsLen; i++) {
        var point = new BMap.Point(points[i].lng, points[i].lat); //将标注点转化成地图上的点
        var marker = new BMap.Marker(point); //将点转化成标注点
        map.addOverlay(marker);  //将标注点添加到地图上

        var label = new window.BMap.Label('<a class="maplabel" href="'+returnWhole( points[i].contenturl )+'"  style="color:#fff;display:block;">'+points[i].title+'</a>', { offset: new window.BMap.Size(20, 0) });
        label.setStyle({    //设置label样式                         
		    fontSize:"12px",               
		    border:"0",                    
		    height:"",               
		    width:"",                
		    textAlign:"center",           
		    lineHeight:"24px",           
		    background:"#d4283e", 
		    cursor:"pointer",
		    color:"#fff",
		    padding:"0px 6px",
		    borderRadius:"12px"
		});

		label.addEventListener("click",function() {
            $(".maplabel").unbind("touch").on("touch", jumpToContent(this) );
        });
        marker.setLabel(label);  
   }
   
   setCenterAndZoom(points); 
   
   //setZoom(points)
}





//$(document).click(function(e){
//	
//  var _con = $('ul.nav-list li');   	// 设置目标区域
//  if(!_con.is(e.target) && _con.has(e.target).length === 0){ 	// Mark 1
//      $("ul.nav-list").slideUp(200) ;
//      $("body").css("overflow","visible");
//		$(".header-nav .area-name").removeClass("ac").find("i").addClass("fa-caret-down").removeClass("fa-caret-up") ;   
// }
//  return false;
//});
